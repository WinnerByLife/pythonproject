

def fake_hash_password(password: str):
    return "fakehashed" + password